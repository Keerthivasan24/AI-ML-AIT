import cv2
import json
import os
import numpy as np
from PIL import Image, ImageDraw

SEGMENTS_DIR = "segments"
FULL_IMAGE_PATH = os.path.join(SEGMENTS_DIR, "fullpage.png")
CANNY_IMAGE_PATH = os.path.join(SEGMENTS_DIR, "canny_edges.png")
DOM_PATH = os.path.join(SEGMENTS_DIR, "dom_structure.json")
SEGMENTED_IMAGE_OUTPUT = os.path.join(SEGMENTS_DIR, "segmented_overlay.png")
SEGMENTED_JSON_OUTPUT = os.path.join(SEGMENTS_DIR, "segmented_regions.json")

def load_inputs():
    img = cv2.imread(FULL_IMAGE_PATH)
    canny = cv2.imread(CANNY_IMAGE_PATH, cv2.IMREAD_GRAYSCALE)
    with open(DOM_PATH, 'r', encoding='utf-8') as f:
        dom = json.load(f)
    return img, canny, dom

def match_dom_to_canny(dom, canny_img, min_size=30):
    segments = []
    height, width = canny_img.shape
    overlay = Image.open(FULL_IMAGE_PATH).convert("RGBA")
    draw = ImageDraw.Draw(overlay)

    for i, node in enumerate(dom):
        x, y = int(node["x"]), int(node["y"])
        w, h = int(node["width"]), int(node["height"])

        # Skip tiny or invalid regions
        if w < min_size or h < min_size:
            continue
        if x + w > width or y + h > height:
            continue

        crop = canny_img[y:y+h, x:x+w]
        edge_strength = np.mean(crop)

        # Threshold edge density to ensure it's a visible component
        if edge_strength > 10:
            segments.append({
                "id": f"segment_{i}",
                "x": x,
                "y": y,
                "width": w,
                "height": h,
                "label": node.get("tag", "unknown"),
                "outerHTML": node.get("outerHTML", "")
            })
            draw.rectangle([x, y, x+w, y+h], outline="red", width=2)

    overlay.save(SEGMENTED_IMAGE_OUTPUT)
    print(f"[✓] Segmented overlay saved: {SEGMENTED_IMAGE_OUTPUT}")
    return segments

def save_segments_json(segments):
    with open(SEGMENTED_JSON_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(segments, f, indent=2)
    print(f"[✓] Segmented metadata saved: {SEGMENTED_JSON_OUTPUT}")

def main():
    print("[✓] Loading inputs...")
    img, canny, dom = load_inputs()
    print("[✓] Generating segments from DOM and Canny edges...")
    segments = match_dom_to_canny(dom, canny)
    save_segments_json(segments)

if __name__ == "__main__":
    main()

import json
import os
import re

SEGMENTS_FOLDER = "segments"
SEGMENTS_JSON_PATH = os.path.join(SEGMENTS_FOLDER, "segmented_regions.json")
DOM_JSON_PATH = os.path.join(SEGMENTS_FOLDER, "dom_structure.json")
RECIPE_JSON_PATH = os.path.join(SEGMENTS_FOLDER, "recipe.json")

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def is_overlap(seg_box, dom_box, iou_threshold=0.3):
    x1, y1, w1, h1 = seg_box
    x2, y2, w2, h2 = dom_box

    xi1 = max(x1, x2)
    yi1 = max(y1, y2)
    xi2 = min(x1 + w1, x2 + w2)
    yi2 = min(y1 + h1, y2 + h2)

    inter_width = max(0, xi2 - xi1)
    inter_height = max(0, yi2 - yi1)
    inter_area = inter_width * inter_height

    seg_area = w1 * h1
    dom_area = w2 * h2
    union_area = seg_area + dom_area - inter_area

    iou = inter_area / union_area if union_area else 0
    return iou > iou_threshold

def extract_component_name(dom):
    tag = dom.get("tag", "").lower()
    html = dom.get("outerHTML", "").lower()

    # Priority by tag name
    if tag in ["button", "input", "textarea"]:
        return "form_element"
    elif tag in ["nav"]:
        return "navigation"
    elif tag in ["img"]:
        return "image"
    elif tag in ["h1", "h2", "h3", "header"]:
        return "header"
    elif tag in ["footer"]:
        return "footer"
    elif tag in ["section", "article"]:
        return "section"
    elif tag == "div":
        # Try class fallback
        if "card" in html:
            return "card"
        elif "header" in html:
            return "header"
        elif "footer" in html:
            return "footer"
        elif "container" in html:
            return "container"
        elif "nav" in html:
            return "navigation"
    return "unknown"

def match_segment_with_dom(segment, dom_elements):
    seg_box = (segment["x"], segment["y"], segment["width"], segment["height"])
    for dom in dom_elements:
        dom_box = (dom["x"], dom["y"], dom["width"], dom["height"])
        if is_overlap(seg_box, dom_box):
            return dom
    return None

def generate_recipe():
    segments = load_json(SEGMENTS_JSON_PATH)
    dom_elements = load_json(DOM_JSON_PATH)

    recipe = []
    for idx, segment in enumerate(segments):
        image_path = os.path.join(SEGMENTS_FOLDER, f"segment_{idx+1}.png")
        matched_dom = match_segment_with_dom(segment, dom_elements)
        component_name = extract_component_name(matched_dom) if matched_dom else "unknown"
        recipe_entry = {
            "id": f"segment_{idx+1}",
            "image_path": image_path,
            "bounding_box": {
                "x": segment["x"],
                "y": segment["y"],
                "width": segment["width"],
                "height": segment["height"]
            },
            "component_name": component_name,
            "dom": {
                "tag": matched_dom["tag"] if matched_dom else None,
                "outerHTML": matched_dom["outerHTML"] if matched_dom else None
            }
        }

        recipe.append(recipe_entry)

    with open(RECIPE_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(recipe, f, indent=2)
    print(f"recipe.json with component names saved to: {RECIPE_JSON_PATH}")

if __name__ == "__main__":
    generate_recipe()

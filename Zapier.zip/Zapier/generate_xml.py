import json
import xml.etree.ElementTree as ET
import os


def dict_to_xml_component(comp_data):
    comp_elem = ET.Element("component", {
        "id": str(comp_data.get("id")),
        "type": comp_data.get("component_name", "unknown")
    })

    ET.SubElement(comp_elem, "imagePath").text = comp_data.get("image_path", "")

    # bounding_box dict
    bbox = comp_data.get("bounding_box", {})
    ET.SubElement(comp_elem, "boundingBox", {
        "x": str(bbox.get("x", 0)),
        "y": str(bbox.get("y", 0)),
        "width": str(bbox.get("width", 0)),
        "height": str(bbox.get("height", 0))
    })

    # DOM info
    dom = comp_data.get("dom", {})
    dom_elem = ET.SubElement(comp_elem, "dom")
    ET.SubElement(dom_elem, "tag").text = dom.get("tag", "")
    ET.SubElement(dom_elem, "outerHTML").text = dom.get("outerHTML", "")

    return comp_elem


def convert_recipe_to_xml(recipe_path, output_path="artifacts/recipe.xml"):
    with open(recipe_path, "r", encoding="utf-8") as f:
        recipe = json.load(f)

    root = ET.Element("recipe")

    # Handle both list and single object
    if isinstance(recipe, dict):
        root.append(dict_to_xml_component(recipe))
    elif isinstance(recipe, list):
        for comp in recipe:
            root.append(dict_to_xml_component(comp))

    tree = ET.ElementTree(root)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    tree.write(output_path, encoding="utf-8", xml_declaration=True)
    print(f"[✓] XML saved to: {output_path}")


recipe_path = r"E:\Keerthivasan\Zapier\artifacts\_artifacts\recipe.json"
output_path = r"E:\Keerthivasan\Zapier\artifacts\_artifacts\recipe.xml"

convert_recipe_to_xml(recipe_path, output_path)
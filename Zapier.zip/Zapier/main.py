from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from PIL import Image
import io
import time
import os
import cv2
import json

def capture_fullpage_screenshot(url, output_path='segments/fullpage.png'):
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_argument("--window-size=1920,3000")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(url)
    time.sleep(3)

    total_height = driver.execute_script("return document.body.scrollHeight")
    driver.set_window_size(1920, total_height)
    time.sleep(1)

    os.makedirs("segments", exist_ok=True)

    # Screenshot full page
    screenshot = driver.get_screenshot_as_png()
    image = Image.open(io.BytesIO(screenshot))
    image.save(output_path)
    print(f"[✓] Full page screenshot saved: {output_path}")

    # Extract DOM elements and their positions
    dom_data = []
    elements = driver.find_elements("xpath", "//*")
    for elem in elements:
        try:
            location = elem.location
            size = elem.size
            html = driver.execute_script("return arguments[0].outerHTML", elem)
            dom_data.append({
                "tag": elem.tag_name,
                "x": location["x"],
                "y": location["y"],
                "width": size["width"],
                "height": size["height"],
                "outerHTML": html[:200]  # Truncate to avoid huge dump
            })
        except Exception as e:
            continue

    # Save DOM structure
    print("Extracting Dom Path.......")
    dom_output_path = "segments/dom_structure.json"
    with open(dom_output_path, "w", encoding="utf-8") as f:
        json.dump(dom_data, f, indent=2)
    print(f"[✓] DOM structure saved: {dom_output_path}")

    driver.quit()
    return output_path

def apply_canny(image_path, output_path='segments/canny_edges.png'):
    img = cv2.imread(image_path)
    if img is None:
        print(f"[!] Failed to read image: {image_path}")
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    cv2.imwrite(output_path, edges)
    print(f"[✓] Canny edge map saved: {output_path}")

if __name__ == "__main__":
    url = "https://zapier.com/workflows"  # Change as needed
    screenshot_path = capture_fullpage_screenshot(url)
    apply_canny(screenshot_path)

from PIL import Image
import json
import os

# Paths
full_image_path = "segments/fullpage.png"
regions_json_path = "segments/segmented_regions.json"
output_folder = "segments/individual_segments"

# Create output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Load full page image
full_image = Image.open(full_image_path)

# Load region data from JSON
with open(regions_json_path, "r") as f:
    regions = json.load(f)

# Generate individual segments
segment_metadata = []
for idx, region in enumerate(regions):
    x, y, w, h = region["x"], region["y"], region["width"], region["height"]
    segment_img = full_image.crop((x, y, x + w, y + h))
    segment_filename = f"segment_{idx + 1}.png"
    segment_path = os.path.join(output_folder, segment_filename)
    segment_img.save(segment_path)

    segment_metadata.append({
        "segment": segment_filename,
        "x": x,
        "y": y,
        "width": w,
        "height": h
    })

# Save metadata JSON
metadata_path = os.path.join(output_folder, "labelled_segments.json")
with open(metadata_path, "w") as f:
    json.dump(segment_metadata, f, indent=2)

print(f" {len(segment_metadata)} segments generated in '{output_folder}'")

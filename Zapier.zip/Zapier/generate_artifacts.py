import os
import shutil
from datetime import datetime

def generate_artifacts_folder():

    files_to_collect = {
        "fullpage.png": "segments/fullpage.png",
        "canny_edges.png": "segments/canny_edges.png",
        "dom_structure.json": "segments/dom_structure.json",
        "segmented_regions.json": "segments/segmented_regions.json",
        "segment_overlay.png": "segments/segmented_overlay.png",
        "recipe.json": "segments/recipe.json",
    }


    segment_images = [
        f for f in os.listdir("segments")
        if f.startswith("segment_") and f.endswith(".png")
    ]

    # Create a timestamped folder
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    artifacts_dir = f"artifacts/_artifacts"
    os.makedirs(artifacts_dir, exist_ok=True)

    # Copy files
    for name, src in files_to_collect.items():
        if os.path.exists(src):
            shutil.copy(src, os.path.join(artifacts_dir, name))

    # Copy segment images
    for img in segment_images:
        shutil.copy(
            os.path.join("segments", img),
            os.path.join(artifacts_dir, img)
        )

    print(f"[✓] Artifacts saved in: {artifacts_dir}")

if __name__ == "__main__":
    generate_artifacts_folder()
